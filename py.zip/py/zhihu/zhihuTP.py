'''
Created on 2017年12月11日

@author: yet726
'''
from urllib import request
from bs4 import BeautifulSoup as bs
import re
import pymysql
from pathlib import Path

# req = request.Request("https://www.zhihu.com/question/19569657");
# req = request.Request("http://toutiao.com/group/6498864350747427342/");
req = request.Request("https://www.zhihu.com/question/19569657");
req.add_header("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36")
resp= request.urlopen(req)
resp.getcode()
html_doc = resp.read().decode("utf-8")
soup = bs(html_doc,'html.parser')

for img in soup.findAll("img",src=re.compile(r"^https")):
#     print(img)
    print(img['src'])
    
    photo_url =  img.get('src')
    photo_name = photo_url.rsplit('/', 1)[-1]
    file = open('E:/Python_learning/{}'.format(photo_name),'wb')
    req = request.urlopen(photo_url).read()
    file.write(req)
    print(photo_url)
    
