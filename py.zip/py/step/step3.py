# -*- coding:utf-8 -*-
from tool import TagManager
# 提取标签页到excel
file = open('web/booktag.html','rb')
content = file.read()
TagManager.makeBookTag(content, r'web/bookTag.xlsx')