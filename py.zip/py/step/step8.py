from tool.DbManager import DbManager 
from tool import TagManager 
import os
# 扫描book目录，找出所有图书详情表进行提取，插入数据库

rootdir='../book'
prefix='.html'
database = DbManager()
insertbooksql = "INSERT INTO `bookdetial` (`bookname`,`bookno`,`bookinfo`,`bookintro`,`authorintro`,`peoples`,`starts`,`other`,`mulu`,`comments`) VALUES ("\
                        "'{0}', '{1}', '{2}','{3}','{4}',{5},'{6}','{7}','{8}','{9}')"
for parent,dirnames,filenames in os.walk(rootdir):
    for filename in filenames:
        if filename.endswith(prefix) :
            path=str(parent)+'/'+filename
            print(path)
            content=open(path,'rb').read()
            try:
                draw=TagManager.makeBookInfo(content)
            except:
                continue
            insert1 = insertbooksql.format(draw[1],
                                        draw[0],
                                        draw[2],
                                        draw[3],
                                        draw[4],
                                        draw[5],
                                        draw[6],
                                        draw[7],
                                        draw[8],
                                        draw[9])
            try:
                database.execNonQuery(insert1)
                os.rename(path,path+'lockl')
            except Exception as e:
                print(e)
                continue
        else:
            pass