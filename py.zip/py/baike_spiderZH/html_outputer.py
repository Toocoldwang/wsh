'''
Created on 2017年12月15日

@author: yet726
'''


class HtmlOutputer(object):
    
    
    def __init__(self):
        self.datas = []

    
    def collect_data(self,data):#收集数据
        if data is None:
            return 
        self.datas.append(data)
        

    #ascii
    def output_html(self):#输出
        fouc = open('output.html','w')
        
        fouc.write("<html>")
        fouc.write("<body>")
        fouc.write("<div>")
        for data in self.datas:
            fouc.write("<img src='%s' ></td>" % data['url'])
        fouc.write("</div>") 
        fouc.write("</body>")
        fouc.write("</html>")
        
        fouc.close()
    
    
    
    
    



