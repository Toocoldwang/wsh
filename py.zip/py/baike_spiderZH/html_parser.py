'''
Created on 2017年12月15日

@author: yet726
'''
from bs4 import BeautifulSoup as bs
import re
import urllib.parse
from urllib import request
import pymysql

class HtmlParser(object):
    

    def _get_new_urls(self, page_url, soup):
        new_urls = set()
#         links = soup.findAll('a',href=re.compile(r"https:"))
        links = soup.findAll('a')
        for link in links:  
            new_url = link['href']
            new_full_url = urllib.parse.urljoin(page_url, new_url)
            new_urls.add(new_full_url)
        return new_urls
    
    def _get_new_data(self, page_url, soup):
        res_data = {}
        #url
        res_data['url'] = page_url
        self._get_img(page_url)
        return res_data
    
    def _get_img(self, page_url):
        req = request.Request(page_url);
        req.add_header("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36")
        resp= request.urlopen(req)
        html_doc = resp.read().decode("utf-8")
        new_img = bs(html_doc,'html.parser')
        #.qpic.cn/
        #https://pic4.zhimg.com/50/
        for img in new_img.findAll("img",src=re.compile(r"https://pic4.zhimg.com/")):
            photo_url =  img.get('src')
            photo_name = photo_url.rsplit('/', 1)[-1] + '.jpg'
            file = open('E:/Python_learning/{}'.format(photo_name),'wb')
            req = request.urlopen(photo_url).read()
            file.write(req)
            
            #创建数据库连接
            connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='root',
                                          db='zhihu',
                                          charset='utf8')   
            try:
                #获取会话指针
                with connection.cursor() as cursor:
                    #创建sql
                    sql = "insert into `zhusrs`(`urlname`,`urls`)values(%s,%s)"
                    #执行sql语句
                    cursor.execute(sql,(format(photo_name),photo_url))
                    #提交
                    connection.commit()
            finally:
                connection.close()
            
    
    def parse(self,page_url, html_cont):#解析出新的url列表和数据
        if page_url is None or html_cont is None:
            return
        soup = bs(html_cont, 'html.parser')
        new_urls = self._get_new_urls(page_url,soup)
        new_data = self._get_new_data(page_url,soup)
        return new_urls,new_data
      
    
    



