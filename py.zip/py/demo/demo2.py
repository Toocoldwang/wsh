import wx

'''定义一个窗口类'''
class MainWindow (wx.Frame):
    def __init__(self, parent, title):
        wx.Frame.__init__ (self, parent, title=title, size=(300, 300))
        self.control = wx.TextCtrl (self, style=wx.TE_MULTILINE)

        self.setupMenuBar ()
        self.Show (True)

    def setupMenuBar(self):
        self.CreateStatusBar ()

        menubar = wx.MenuBar ()
        menufile = wx.Menu ()
        menufile2 = wx.Menu ()

        mnuabout = menufile.Append (wx.ID_ABOUT, '&About', 'about this shit')
        mnuexit = menufile.Append (wx.ID_EXIT, '&Exit', 'end program')

        menubar.Append (menufile, '&File')
        menubar.Append (menufile2, '&save')

        # 事件绑定
        self.Bind (wx.EVT_MENU, self.onAbout, mnuabout)
        self.Bind (wx.EVT_MENU, self.onExit, mnuexit)

        self.SetMenuBar (menubar)

    '''点击about的事件响应'''
    def onAbout(self, evt):
        dlg = wx.MessageDialog (self, 'This app is a simple text editor', 'About my app', wx.OK)
        dlg.ShowModal ()
        dlg.Destroy ()

    '''点击退出'''
    def onExit(self, evt):
        self.Close (True)

if __name__=='__main__':
    app = wx.App (False)
    frame = MainWindow (None, 'Small Editor')
    app.MainLoop ()  # 循环监听事件