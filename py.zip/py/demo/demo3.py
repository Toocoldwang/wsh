# coding=utf-8
import re

cnt = '"aliMallSeller":False,"anony":True,"appendComment":"","attributes":"","attributesMap":"","aucNumId":"","auctionPicUrl":"","auctionPrice":"","auctionSku":"化妆品净含量:75ml","auctionTitle":"","buyCount":0,"carServiceLocation":"","cmsSource":"天猫","displayRatePic":"","displayRateSum":0,"displayUserLink":"","displayUserNick":"t***凯","displayUserNumId":"","displayUserRateLink":"","dsr":0.0,"fromMall":True,"fromMemory":0,"gmtCreateTime":1504930533000,"goldUser":False,"id":322848226237,"pics":["//img.alicdn.com/bao/uploaded/i3/2699329812/TB2hr6keQ.HL1JjSZFlXXaiRFXa_!!0-rate.jpg"],"picsSmall":"","position":"920-11-18,20;","rateContent":"送了面膜 和晶莹水 skii就是A 不错","rateDate":"2017-09-09 12:15:33","reply":"一次偶然的机会，遇见了亲，一次偶然的机会，亲选择了SK-II，生命中有太多的选择，亲的每一次选择都是一种缘分。让SK-II与您形影不离，任岁月洗礼而秀美如初~每日清晨拉开窗帘迎来的不仅止破晓曙光，还有崭新的自己~【SK-II官方旗舰店Lily】","sellerId":917264765,"serviceRateContent":"","structuredRateList":[],"tamllSweetLevel":3,"tmallSweetPic":"tmall-grade-t3-18.png","tradeEndTime":1504847657000,"tradeId":"","useful":True,"userIdEncryption":"","userInfo":"","userVipLevel":0,"userVipPic":""'

nickname = []
regex = re.compile ('"displayUserNick":"(.*?)"')
print (regex)
nk = re.findall (regex, cnt)
for i in nk:
    print(i)
nickname.extend (nk)
print
nickname

ak = re.findall ('"auctionSku":"(.*?)"', cnt)
for j in ak:
    print(j)

rc = re.findall ('"rateContent":"(.*?)"', cnt)
for n in rc:
    print(n)

rd = re.findall ('"rateDate":"(.*?)"', cnt)
for m in rd:
    print(m)