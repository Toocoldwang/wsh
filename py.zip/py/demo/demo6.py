import pandas as pd
from pandas import Series,DataFrame


df = pd.read_csv(r'E:\PythonFile\SK-II_TmallContent.csv',encoding='gbk')  #否则中文乱码
#print df.columns
df.columns = ['useName','date','type','content']
print (df[:5])

from pyecharts import Pie

pie = Pie('净含量购买分布')
v = df['type'].tolist()
print (v[:5])

#n1 = v.count(u'\u5316\u5986\u54c1\u51c0\u542b\u91cf:230ml')
n1 = v.count(u'化妆品净含量:75ml')
n2 = v.count(u'化妆品净含量:160ml')
n3 = v.count(u'化妆品净含量:230ml')
n4 = v.count(u'化妆品净含量:330ml')
#print n1,n2,n3,n4  #800 87 808 124

N = [n1,n2,n3,n4]
#print N  #[800,87,808,124]

attr = ['体验装','畅销经典','忠粉挚爱','屯货之选']
pie.add('ryana',attr,N,is_label_show = True)
pie