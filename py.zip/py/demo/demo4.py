import requests
import re


#urls = []
#for i in list(range(1,500)):
#    urls.append('https://rate.tmall.com/list_detail_rate.htm?itemId=15332134505&spuId=294841&sellerId=917264765&order=1&currentPage=%s'%i)

tmpt_url = 'https://rate.tmall.com/list_detail_rate.htm?itemId=15332134505&spuId=294841&sellerId=917264765&order=1&currentPage=%d'
urllist = [tmpt_url%i for i in range(1,100)]
#print urllist

nickname = []
auctionSku = []
ratecontent = []
ratedate = []
headers = ''

for url in urllist:
    content = requests.get(url).text
    nk = re.findall('"displayUserNick":"(.*?)"',content)  #findall(正则规则，字符串) 方法能够以列表的形式返回能匹配的字符串
    #print nk
    nickname.extend(nk)
    auctionSku.extend(re.findall('"auctionSku":"(.*?)"',content))
    ratecontent.extend(re.findall('"rateContent":"(.*?)"',content))
    ratedate.extend(re.findall('"rateDate":"(.*?)"',content))
    # print (nickname,ratedate)


for i in list(range(0,len(nickname))):
    text =','.join((nickname[i],ratedate[i],auctionSku[i],ratecontent[i]))+'\n'
    print(text)
    with open(r"E:\PythonFile\SK-II_TmallContent.csv",'a+') as file:
        file.write(text+' ')
        print("写入成功")