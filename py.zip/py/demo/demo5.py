
import pandas as pd
from pandas import Series,DataFrame
import jieba
from collections import Counter



df = pd.read_csv(r'E:\PythonFile\SK-II_TmallContent.csv')
#print df.columns
df.columns = ['useName','date','type','content']
#print df[:10]


tlist = Series.as_matrix(df['content']).tolist()
text = [i for i in tlist if type(i)!= float] #if type(i)!= float一定得加不然报错
text = ' '.join(text)
#print text

wordlist_jieba = jieba.cut(text,cut_all=True)
stoplist = {}.fromkeys([u'的', u'了', u'是',u'有'])  #自定义中文停词表，注意得是unicode
print(stoplist)
wordlist_jieba = [i for i in wordlist_jieba if i not in stoplist]  #and len(i) > 1
#print u"[全模式]: ", "/ ".join(wordlist_jieba)

count = Counter(wordlist_jieba)   #统计出现次数,以字典的键值对形式存储，元素作为key，其计数作为value。
result = sorted(count.items(), key=lambda x: x[1], reverse=True)  #key=lambda x: x[1]在此表示用次数作为关键字

for word in result:
    print(word[0], word[1])


from pyecharts import WordCloud

data = dict(result[:100])
wordcloud = WordCloud('高频词云',width = 800,height = 600)
wordcloud.add('ryana',data.keys(),data.values(),word_size_range = [30,300])
wordcloud