import pandas as pd

# help(pd)

for i in range(100,1000):
    if '1' in str(i):
        print(i)


