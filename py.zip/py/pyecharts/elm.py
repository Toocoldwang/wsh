from lxml import etree
import requests
import sys
import time

url = 'https://www.ele.me/place/ws101hcw982?latitude=22.52721&longitude=113.95232'
response = requests.get(url)
print (response.status_code)

time.sleep(10)
html = response.content
selector = etree.HTML(html)
rez = selector.xpath('//*[@class="place-rstbox clearfix"]')
print ('haha',rez)  #[]
for i in rez:
    Name = i.xpath('//*[@class="rstblock-title"]/text()')
    print(Name)
    msales = i.xpath('//*[@class="rstblock-monthsales"]/text()')
    tip = i.xpath('//*[@class="rstblock-cost"]/text()')
    stime = i.xpath('//*[@class="rstblock-logo"]/span/text()')

    print (u'店名')
    for j in Name:
        print(j)
        break