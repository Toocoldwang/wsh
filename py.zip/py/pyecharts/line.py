from pyecharts import Line
attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
v2 = [10,25,8,60,20,80]
line = Line('折线示例图')
line.add('商家A',attr,v1,mark_point = ['average'])
line.add('商家B',attr,v2,is_smooth = True, mark_line = ['max','average'])
line.render('../html/line01.html')

#代码2：(定制折线图)
from pyecharts import Line
attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
v2 = [10,25,8,60,20,80]
line = Line('折线示例图')
line.add('商家A',attr,v1,mark_point = ['average','max','min'],
    mark_point_symbol = 'diamond',
    mark_point_textcolor = '#40ff27')
line.add('商家B',attr,v2,mark_point = ['average','max','min'],
    mark_point_symbol = 'arrow',
    mark_point_symbolsize = 40)
line.render('../html/line02.html')

#代码3：(面积图)
from pyecharts import Line
attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
v2 = [10,25,8,60,20,80]
line = Line('折线面积示例图')
line.add('商家A',attr,v1,is_fill = True,
    line_opacity = 0.2,
    area_opacity = 0.4,
    symbol = None)
line.add('商家B',attr,v2,is_fill = True,
    line_color = '#000',
    area_opacity = 0.3,
    is_smooth = True)
line.render('../html/lineArea03.html')



line = Line("折线图-阶梯图示例")
line.add("商家A", attr, v1, is_step=True, is_label_show=True)
line.render('../html/lineArea04.html')