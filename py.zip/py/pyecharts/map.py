#代码1：
from pyecharts import Map
value = [155,10,66,78]
attr = ['福建','山东','北京','上海']
map = Map('全国地图示例',width = 1200,height = 600)
map.add('',attr,value,maptype = 'china')
map.render('../html/map01.html')

#代码2：
from pyecharts import Map
value = [155,10,66,78]
attr = ['汕头市','汕尾市','揭阳市','肇庆市']
map = Map('广东地图示例',width = 1200,height = 600)
map.add('',attr,value,maptype = 'guangong',
        is_visualmap = True,
        visual_text_color = '#000',
        is_label_show = True
        )
map.render('../html/map02.html')




value = [155, 10, 66, 78]
attr = ["福建", "山东", "北京", "上海"]
map = Map("全国地图示例", width=1200, height=600)
map.add("", attr, value, maptype='china')
map.render('../html/map03.html')



value = [95.1, 23.2, 43.3, 66.4, 88.5]
attr= ["China", "Canada", "Brazil", "Russia", "United States"]
map = Map("世界地图示例", width=1200, height=600)
map.add("", attr, value, maptype="world", is_visualmap=True,
        visual_text_color='#000')
map.render('../html/map04.html')