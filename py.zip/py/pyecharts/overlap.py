#代码1：bar + line 叠加

from pyecharts import Bar,Line,Overlap
attr = ['A','B','C','D','E','F']
v1 = [10,20,30,40,50,60]
v2 = [38,28,35,58,65,70]
bar = Bar('Line - Bar示例')
bar.add('bar',attr,v1)
line = Line()
line.add('line',attr,v2)

overlop = Overlap()
overlop.add(bar)
overlop.add(line)
overlop.render('../html/line-bar01.html')

#代码2：EffectScatter + Line 叠加

from pyecharts import Line,EffectScatter,Overlap
attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,10,90]
line = Line('饼图示例')
line.add('',attr,v1,is_random = True)

es = EffectScatter()
es.add('',attr,v1,effect_scale=8)   #闪烁
overlop = Overlap()
overlop.add(es)
overlop.add(line)
overlop.render('../html/line-es01.html')