from pyecharts import Pie

attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
pie = Pie('饼图示例')
pie.add('',attr,v1,is_label_show = True)
pie.render('../html/pie01.html')

#代码2：(环形图)
from pyecharts import Pie

attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
pie = Pie('饼图-环形图示例',title_pos = 'center')
pie.add(
            '',attr,v1,
            radius = [40,75],
            is_label_show = True,
            label_text_color = None,
            legend_orient = 'vertical', #图例垂直
            legend_pos = 'left'
        )
pie.render('../html/pie02.html')