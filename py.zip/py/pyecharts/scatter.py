from pyecharts import Scatter
v1 = [5,20,35,50,65,80]
v2 = [10,20,30,40,50,60]
scatter = Scatter('散点示例图')
scatter.add('A',v1,v2)
scatter.add('B',v1[::-1],v2)    #v1[::-1]代表切片倒序
scatter.render('../html/scatter01.html')

#代码2：(引入第三维/类似气泡图)
from pyecharts import Scatter
v1 = [5,20,35,50,65,80]
v2 = [10,20,30,40,50,60]
scatter = Scatter('散点-气泡示例图')
scatter.add('A',v1,v2)
scatter.add('B',v1[::-1],v2,is_visualmap = True,vasual_type = 'size',vasual_range_size = [20,80])   #v1[::-1]代表切片倒序
scatter.render('../html/scatter02.html')


from pyecharts import EffectScatter
v1 = [10, 20, 30, 40, 50, 60]
v2 = [25, 20, 15, 10, 60, 33]
es = EffectScatter("动态散点图示例")
es.add("effectScatter", v1, v2)
es.render('../html/scatter03.html')



es = EffectScatter("动态散点图各种图形示例")
es.add("", [10], [10], symbol_size=20, effect_scale=3.5,
       effect_period=3, symbol="pin")
es.add("", [20], [20], symbol_size=12, effect_scale=4.5,
       effect_period=4,symbol="rect")
es.add("", [30], [30], symbol_size=30, effect_scale=5.5,
       effect_period=5,symbol="roundRect")
es.add("", [40], [40], symbol_size=10, effect_scale=6.5,
       effect_brushtype='fill',symbol="diamond")
es.add("", [50], [50], symbol_size=16, effect_scale=5.5,
       effect_period=3,symbol="arrow")
es.add("", [60], [60], symbol_size=6, effect_scale=2.5,
       effect_period=3,symbol="triangle")
es.render('../html/scatter04.html')