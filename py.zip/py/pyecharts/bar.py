from pyecharts import Bar

attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
v2 = [10,25,8,60,20,80]
bar = Bar('柱状信息堆叠图',width=1200,height=600)
bar.add('商家A',attr,v1,is_stack = True)  #is_stack = True才表示堆叠在一起
bar.add('商家B',attr,v2,is_stack = True)
bar.use_theme('dark')#主题
bar.render('../html/bar01.html')


# 并列（柱形）图
from pyecharts import Bar

attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
v2 = [10,25,8,60,20,80]
bar = Bar('标记线和标记示例')
bar.add('商家A',attr,v1,mark_point = ['average']) #标记点：商家A的平均值
bar.add('商家B',attr,v2,mark_line = ['min','max'])    #标记线：商家B最小/最大值
bar.render('../html/bar02.html')

# 横向并列（柱形）图
from pyecharts import Bar

attr = ['衬衫','羊毛衫','雪纺衫','裤子','高跟鞋','袜子']
v1 = [5,20,36,10,75,90]
v2 = [10,25,8,60,20,80]
bar = Bar('X 轴与 Y 轴交换')
bar.add('商家A',attr,v1)
bar.add('商家B',attr,v2,is_convert = True)    # is_convert = True:X 轴与 Y 轴交换
bar.render('../html/bar03.html')

#滚动
import random
attr = ["{}天".format(i) for i in range(1,31)]
v1 = [random.randint(0, 30) for _ in range(1,31)]
bar = Bar("Bar - datazoom - inside 示例")
bar.add("", attr, v1, is_datazoom_show=True, datazoom_type='inside',
        datazoom_range=[10, 25])
bar.render('../html/bar04.html')


#瀑布
from pyecharts import Bar
attr = ["{}月".format(i) for i in range(1, 8)]
v1 = [0, 100, 200, 300, 400, 220, 250]
v2 = [1000, 800, 600, 500, 450, 400, 300]
bar = Bar("瀑布图示例")
# 利用第一个 add() 图例的颜色为透明，即 'rgba(0,0,0,0)'，并且设置 is_stack 标志为 True
bar.add("", attr, v1, label_color=['rgba(0,0,0,0)'], is_stack=True)
bar.add("月份", attr, v2, is_label_show=True, is_stack=True, label_pos='inside')
bar.render('../html/bar05.html')