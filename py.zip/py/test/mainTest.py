from test import pymethod
class SpiderMainTest():
    def __init__(self):
        self.webMeth = pymethod.methmain()
    def craw(self,path,par):
        result = self.webMeth.TestSuds(path, par)
        print(result)

if __name__=='__main__':
    obj_spider =SpiderMainTest()
    obj_spider.craw('http://www.webxml.com.cn/webservices/qqOnlineWebService.asmx?wsdl','1099583691')
    # webMethok = pymethod.methmain ()
    # resultend = webMethok.TestSuds('http://www.webxml.com.cn/webservices/qqOnlineWebService.asmx?wsdl','1099583691')
    # print (resultend)