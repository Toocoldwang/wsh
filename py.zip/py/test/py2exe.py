from distutils.core import setup
import py2exe
includes = ["encodings", "encodings.*"]
options = {"py2exe":
             {   "compressed": 1,#压缩
                 "optimize": 2,
                 "includes": includes,
                 "bundle_files": 1 #所有文件打包成一个exe文件
             }
           }
setup(
     version = "0.1.0",#版本号
     description = "py program", #类似于打开任务管理器后，后边的进程描述。这里自己可以定义自己的名称
     name = "wang",#作者
     options = options,#讲所有文件打包成一个exe,如果无此代码则会在dist文件夹内生成许多依赖的文件，加上此代码则会把依赖文件都加入一个exe，发给他人使用时不依赖对方机器环境
     zipfile=None,
     windows=[{"script": "test4.py", "icon_resources": [(1, "PyCrust.ico")] }],#前一个参数都好理解是你的python文件名，后一个参数就是图标所依赖的资源文件，只需要给出合理的ico图标路径
  )