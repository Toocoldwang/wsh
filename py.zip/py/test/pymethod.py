# 方法类 供其他地方调用

import suds

from suds.client import Client

# url = "http://www.webxml.com.cn/webservices/qqOnlineWebService.asmx?wsdl"
# client = suds.client.Client(url)
# print(client)
# #getHealthyHeBei是webService提供的方法
# result = client.service.qqCheckOnline("1099583691")
#打印出结果
# print("打印结果"+result)

class methmain(object):
    def TestSuds(self,path,par):
        url = path
        client = suds.client.Client(url)
        print(client)
        result = client.service.qqCheckOnline(par)
        return result

