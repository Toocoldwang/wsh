
#文件操作
print()
print("文件操作")
# 打开一个文件
f = open("E:/PythonFile/foo.txt", "w")
f.write("Python 是一个非常好的语言。\n是的，的确非常好!!\n" )
# 关闭打开的文件
f.close()