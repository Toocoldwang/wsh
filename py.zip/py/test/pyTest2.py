# 测试py函数

import decimal #数据精度操作
from sys import argv, path  # 导入特定的成员
import random#生成随机数

#系统路径
print ('================python from import===================================')
print ('path:', path)  # 因为已经导入path成员，所以此处引用时不需要加sys.path
print()

#字符串
s = 'Hello, Runoob'
y=str(s)
print(y);print("\n");print(repr(s))

# #input 键盘输入
# print()
# print("键盘输入")
# str = input("请输入：");
# print ("你输入的内容是: ", str)


#格式化
print ("我叫 %s 今年 %d 岁! %s" % ('小明', 10,'很高兴遇见你'))


#range 遍历
for i in range(1, 6):
    print(i)
print()
for y in range(4):
    print(y)


#Decimal 计算精度丢失
a = decimal.Decimal('5.1')
b = decimal.Decimal('2')
print("The result is", a-b)
print("The result is", 4.3-2)

for value in [ 'Infinity', 'NaN', '0' ]:
    print(value)

a = decimal.Decimal('1.3')
b = decimal.Decimal('1.7')
print (a / b)
with decimal.localcontext () as ctx:
    ctx.prec = 3#控制保留多少位
    print (a / b)


#文件操作
print()
print("文件操作")
# 打开一个文件
f = open("E:/PythonFile/foo.txt", "w")
f.write("Python 是一个非常好的语言。\n是的，的确非常好!!\n" )
# 关闭打开的文件
f.close()


#随机数操作
# chooseSjs=random.choice(['apple', 'pear', 'banana'])
# print("选择随机数："+chooseSjs)
# createSjs=random.sample(range(100), 10)
# print("生成随机数："+createSjs)

print(random.random())
print(random.randrange(100))
print(random.randrange(50,100))