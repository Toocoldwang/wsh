# 测试webservice接口
import suds
from suds.clientsocket import Client
class SpiderMainOne(object):
    def craw(self,path,par):
        url = path
        client = suds.client.Client (url)
        print (client)
        result = client.service.qqCheckOnline (par)
        print("输出结果为："+result)

#测试方法跳转 实现webservice 的调用
if __name__=='__main__':
    obj_spider =SpiderMainOne()
    obj_spider.craw('http://www.webxml.com.cn/webservices/qqOnlineWebService.asmx?wsdl','1099583691')