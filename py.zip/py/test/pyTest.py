# 测试python基础知识

x=2;y=5

print(x, end=" ");print("aaaaaa")#用空格代替不换行
print((x, y))
print()


#简单运算
print()
print("简单运算")
print("The result is", 2**5)
print("The result is", 2*5)
print("The result is", 2/5)
print("The result is", 2//5)
print("The result is", 5.1-2)
print("The result is", 4.3-2)
print("The result is", 5+4)
print("The result is", 5%2)

a = 21
b = 10
c = 0
if (a == b):
    print ("1 - a 等于 b")
else:
    print ("1 - a 不等于 b")

if (a != b):
    print ("2 - a 不等于 b")
else:
    print ("2 - a 等于 b")

if (a < b):
    print ("3 - a 小于 b")
else:
    print ("3 - a 大于等于 b")

if (a > b):
    print ("4 - a 大于 b")
else:
    print ("4 - a 小于等于 b")

# 修改变量 a 和 b 的值
a = 5;
b = 20;
if (a <= b):
    print ("5 - a 小于等于 b")
else:
    print ("5 - a 大于  b")

if (b >= a):
    print ("6 - b 大于等于 a")
else:
    print ("6 - b 小于 a")




#字符串
print()
print("字符串")
str = 'Runoob'
print (str)  # 输出字符串
print (str[0:-1])  # 输出第一个到倒数第二个的所有字符
print (str[0])  # 输出字符串第一个字符
print (str[2:5])  # 输出从第三个开始到第五个的字符
print (str[2:])  # 输出从第三个开始的后的所有字符
print (str * 2)  # 输出字符串两次
print (str + "TEST")  # 连接字符串

#列表
print()
print("列表")
list = ['abcd', 786, 2.23, 'runoob', 70.2]
tinylist = [123, 'runoob']
print (list)  # 输出完整列表
print (list[0])  # 输出列表第一个元素
print (list[1:3])  # 从第二个开始输出到第三个元素
print (list[2:])  # 输出从第三个元素开始的所有元素
print (tinylist * 2)  # 输出两次列表
print (list + tinylist)  # 连接列表
# list.append("Aaaaa")#往list中添加元素
# list.pop(4)#往list中删除元素
list[0] = "aaaaaaaaaa"#修改list中的元素
print (list)  # 输出完整列表

#元组
print()
print("元组")
tuple = ('abcd', 786, 2.23, 'runoob', 70.2)
tinytuple = (123, 'runoob')
print (tuple)  # 输出完整元组
print (tuple[0])  # 输出元组的第一个元素
print (tuple[1:3])  # 输出从第二个元素开始到第三个元素
print (tuple[2:])  # 输出从第三个元素开始的所有元素
print (tinytuple * 2)  # 输出两次元组
print (tuple + tinytuple)  # 连接元组

tup1 = ()    # 空元组
tup2 = (20,) # 一个元素，需要在元素后添加逗号



#集合set
print()
print("集合")
student = {'Tom', 'Jim', 'Mary', 'Tom', 'Jack', 'Rose'}
print (student)  # 输出集合，重复的元素被自动去掉
# 成员测试
if ('Rose' in student):
    print ('Rose 在集合中')
else:
    print ('Rose 不在集合中')

# set可以进行集合运算
a = set ('abracadabra')
b = set ('alacazam')
print (a)
print (a - b)  # a和b的差集
print (a | b)  # a和b的并集
print (a & b)  # a和b的交集
print (a ^ b)  # a和b中不同时存在的元素



#字典 类似map
print()
print("字典")
dict = {}
dict['one'] = "1 - 菜鸟"
dict[2] = "2 - 菜鸟"
tinydict = {'name': 'runoob', 'code': 1, 'site': 'www.runoob.com'}
print (dict['one'])  # 输出键为 'one' 的值
print (dict[2])  # 输出键为 2 的值
print (tinydict)  # 输出完整的字典
print (tinydict.keys ())  # 输出所有键
print (tinydict.values ())  # 输出所有值

# dict ([('Runoob', 1), ('Google', 2), ('Taobao', 3)])
# {'Taobao': 3, 'Runoob': 1, 'Google': 2}
#
# {x: x ** 2 for x in (2, 4, 6)}
# {2: 4, 4: 16, 6: 36}
#kk
# dict (Runoob=1, Google=2, Taobao=3)
# {'Taobao': 3, 'Runoob': 1, 'Google': 2}



#zip
print()
print("zip的使用 遍历多个list")
questions = ['name', 'quest', 'favorite color']
answers = ['lancelot', 'the holy grail', 'blue']
for q, a in zip(questions, answers):
    print('What is your {0}?  It is {1}.'.format(q, a))


#enumerate
print()
print("enumerate 的使用遍历得到索引和值")
for i, v in enumerate(['tic', 'tac', 'toe']):
    print(i, v)



#sorted
print()
print("sorted 的是用 返回一个已排序的序列，并不修改原值")
basket = ['apple', 'orange', 'apple', 'pear', 'orange', 'banana']
for f in sorted(set(basket)):
     print(f)


input("\n\n按下 enter 键后退出。")

