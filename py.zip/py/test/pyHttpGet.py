# 测试httpget请求
import urllib.request
from xml.dom.minidom import parseString

#得到上海天气
page = urllib.request.urlopen("http://www.webxml.com.cn/WebServices/WeatherWebService.asmx/getWeatherbyCityName?theCityName=58367")
lines = page.readlines()
page.close()
document = ""
for line in lines :
    document = document + line.decode('utf-8')

dom = parseString(document)
strings = dom.getElementsByTagName("string")
print(strings[6].childNodes[0].data + " " + strings[7].childNodes[0].data)
