#测试读取properties文件 循环去除指定值得方法
import sys
class Properties:
    fileName = ''
    def __init__(self, fileName):
        self.fileName = fileName
    def getProperties(self):
        try:
            pro_file = open (self.fileName, 'r')
            properties = {}
            for line in pro_file:
                if line.find ('=') > 0:
                    strs = line.replace ('\n', '').split ('=')
                    properties[strs[0]] = strs[1]

        except Exception as e:
            raise e
        else:
            pro_file.close ()
        return properties

if __name__=='__main__':
    fileName = sys.path[0] + '\\' + 'systemfile.properties'
    res = fileName.replace ('\\', '/')
    print("文件名："+res)

    p = Properties (res)
    properties = p.getProperties ()
    print (properties)
    print (properties.keys ())
    print (properties.values())
    for key,val in properties.items():
        if key== 'sysNmae':
            print(val)
