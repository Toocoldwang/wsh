function strEnc(pro1,pro2){
	var aa = pro1+pro2;
	return aa;
}