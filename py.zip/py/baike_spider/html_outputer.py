'''
Created on 2017年12月15日

@author: yet726
'''


class HtmlOutputer(object):
    
    
    def __init__(self):
        self.datas = []

    
    def collect_data(self,data):#收集数据
        if data is None:
            return 
        self.datas.append(data)
        

    #ascii
    def output_html(self):#输出
        fouc = open('output.html','w')
        
        fouc.write("<html>")
        fouc.write("<body>")
        fouc.write("<table>")
        for data in self.datas:
            fouc.write("<tr>")
            fouc.write("<td>%s</td>" % data['url'])
            fouc.write("<td>%s</td>" % data['title'].encode('utf-8'))
            fouc.write("<td>%s</td>" % data['summary'].encode('utf-8'))
            fouc.write("</tr>")
        fouc.write("</table>") 
        fouc.write("</body>")
        fouc.write("</html>")
        
        fouc.close()
    
    
    
    
    



