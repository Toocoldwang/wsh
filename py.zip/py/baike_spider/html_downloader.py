'''
Created on 2017年12月15日

@author: yet726
'''
from urllib import request
from bs4 import BeautifulSoup as bs
import re

class HtmlDownloader(object):
    
    
    def download(self,url):
        if url is None:
            return None
        req = request.Request(url);
        req.add_header("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36")
        resp= request.urlopen(req)
        
        if resp.getcode() != 200:
            return None 
        return resp.read().decode("utf-8")
    
        
    
    



